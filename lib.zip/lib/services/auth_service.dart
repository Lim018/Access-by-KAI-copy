import 'package:appwrite/appwrite.dart';
import 'package:appwrite/models.dart';
import '../models/user_model.dart';
import 'appwrite_service.dart';
import 'appwrite_config.dart';
import 'user_service.dart';

class AuthService {
  static Future<User?> getCurrentUser() async {
    try {
      return await AppwriteService.account.get();
    } on AppwriteException {
      return null;
    }
  }

  static Future<UserModel?> signUp({
    required String email,
    required String password,
    required String fullName,
    String? phoneNumber,
  }) async {
    try {
      // Create account
      final user = await AppwriteService.account.create(
        userId: ID.unique(),
        email: email,
        password: password,
        name: fullName,
      );

      // Create user profile in database
      final userProfile = await UserService.createUserProfile(
        userId: user.$id,
        fullName: fullName,
        email: email,
        phoneNumber: phoneNumber,
      );

      return userProfile;
    } catch (e) {
      throw Exception('Failed to create account: $e');
    }
  }

  static Future<UserModel?> signIn({
    required String email,
    required String password,
  }) async {
    try {
      await AppwriteService.account.createEmailSession(
        email: email,
        password: password,
      );

      final user = await getCurrentUser();
      if (user != null) {
        return await UserService.getUserProfile(user.$id);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to sign in: $e');
    }
  }

  static Future<void> signOut() async {
    try {
      await AppwriteService.account.deleteSession(sessionId: 'current');
    } catch (e) {
      throw Exception('Failed to sign out: $e');
    }
  }

  static Future<void> resetPassword({required String email}) async {
    try {
      await AppwriteService.account.createRecovery(
        email: email,
        url: 'https://yourapp.com/reset-password', // Ganti dengan URL aplikasi Anda
      );
    } catch (e) {
      throw Exception('Failed to send reset email: $e');
    }
  }
}