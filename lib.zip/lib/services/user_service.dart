import 'package:appwrite/appwrite.dart';
import '../models/user_model.dart';
import 'appwrite_service.dart';
import 'appwrite_config.dart';

class UserService {
  static Future<UserModel> createUserProfile({
    required String userId,
    required String fullName,
    required String email,
    String? phoneNumber,
  }) async {
    try {
      final document = await AppwriteService.databases.createDocument(
        databaseId: AppwriteConfig.databaseId,
        collectionId: AppwriteConfig.usersCollectionId,
        documentId: ID.unique(),
        data: {
          'userId': userId,
          'fullName': fullName,
          'email': email,
          'phoneNumber': phoneNumber,
          'membershipType': 'Basic',
          'railPoints': 0,
          'kaiPayBalance': 0,
        },
      );

      return UserModel.fromJson(document.data);
    } catch (e) {
      throw Exception('Failed to create user profile: $e');
    }
  }

  static Future<UserModel?> getUserProfile(String userId) async {
    try {
      final documents = await AppwriteService.databases.listDocuments(
        databaseId: AppwriteConfig.databaseId,
        collectionId: AppwriteConfig.usersCollectionId,
        queries: [
          Query.equal('userId', userId),
        ],
      );

      if (documents.documents.isNotEmpty) {
        return UserModel.fromJson(documents.documents.first.data);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to get user profile: $e');
    }
  }

  static Future<UserModel> updateUserProfile({
    required String documentId,
    required Map<String, dynamic> data,
  }) async {
    try {
      final document = await AppwriteService.databases.updateDocument(
        databaseId: AppwriteConfig.databaseId,
        collectionId: AppwriteConfig.usersCollectionId,
        documentId: documentId,
        data: data,
      );

      return UserModel.fromJson(document.data);
    } catch (e) {
      throw Exception('Failed to update user profile: $e');
    }
  }

  static Future<void> updateRailPoints({
    required String userId,
    required int points,
  }) async {
    try {
      final userProfile = await getUserProfile(userId);
      if (userProfile != null) {
        await updateUserProfile(
          documentId: userProfile.id,
          data: {
            'railPoints': userProfile.railPoints + points,
          },
        );
      }
    } catch (e) {
      throw Exception('Failed to update RailPoints: $e');
    }
  }

  static Future<void> updateKaiPayBalance({
    required String userId,
    required int amount,
  }) async {
    try {
      final userProfile = await getUserProfile(userId);
      if (userProfile != null) {
        await updateUserProfile(
          documentId: userProfile.id,
          data: {
            'kaiPayBalance': userProfile.kaiPayBalance + amount,
          },
        );
      }
    } catch (e) {
      throw Exception('Failed to update KAIPay balance: $e');
    }
  }
}