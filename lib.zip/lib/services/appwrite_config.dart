class AppwriteConfig {
  static const String endpoint = 'https://cloud.appwrite.io/v1'; // Ganti dengan endpoint Anda
  static const String projectId = 'your-project-id'; // Ganti dengan project ID Anda
  static const String databaseId = 'kai-app-db';

  // Collection IDs
  static const String usersCollectionId = 'users';
  static const String ticketsCollectionId = 'tickets';
  static const String transactionsCollectionId = 'transactions';
  static const String promosCollectionId = 'promos';
  static const String railPointsCollectionId = 'rail_points';
}